<?php

namespace App\Affilate;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Laravel\Nova\Actions\Actionable;
use Laravel\Nova\Fields\Searchable;

class Affilate extends Model
{
    use searchable , actionable;

    protected $table = 'affilates';
    public $timestamps = true;

    use SoftDeletes;

    protected $dates = ['deleted_at'];
    protected $fillable = array('ssd', 'total_companies');
    protected $visible = array('ssd', 'total_companies');

    public function companies()
    {
        return $this->belongsToMany('App\Company\Company', 'affilate_companies');
    }

    public function user()
    {
        return $this->morphOne('App\User', 'userable');
    }

}
