<?php

namespace App\Providers;

use Laravel\Nova\Nova;
use Laravel\Nova\Cards\Help;
use App\Nova\Metrics\allAdmins;
use App\Nova\Metrics\TotalUsers;
use App\Nova\Metrics\allCompanies;
use App\Nova\Metrics\allCustomers;
use App\Nova\Metrics\allMarheters;
use Illuminate\Support\Facades\Gate;
use Coroowicaksono\ChartJsIntegration\BarChart;
use Laravel\Nova\NovaApplicationServiceProvider;

class NovaServiceProvider extends NovaApplicationServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();
    }

    /**
     * Register the Nova routes.
     *
     * @return void
     */
    protected function routes()
    {
        Nova::routes()
                ->withAuthenticationRoutes()
                ->withPasswordResetRoutes()
                ->register();
    }

    /**
     * Register the Nova gate.
     *
     * This gate determines who can access Nova in non-local environments.
     *
     * @return void
     */
    protected function gate()
    {
        Gate::define('viewNova', function ($user) {
            return in_array($user->email, [
                //
            ]);
        });
    }

    /**
     * Get the cards that should be displayed on the default Nova dashboard.
     *
     * @return array
     */ 
    protected function cards()
    {
        $admins = \App\User::where('userable_type', 'App\General\Admin')->count();
        $marketers = \App\User::where('userable_type', 'App\Affilate\Affilate')->count();
        $companies = \App\User::where('userable_type', 'App\Company\Company')->count();
        $customers = \App\User::where('userable_type', 'App\Customer\Customer')->count();
        
        return [
            (new BarChart())
                ->title('All Users')
                ->animations([
                    'enabled' => true,
                    'easing' => 'easeinout',
                ])
                ->series(array([
                    'barPercentage' => 0.5,
                    'label' => 'Staff ('.$admins.')',
                    'backgroundColor' => '#000',
                    'data' => [\App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 1)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 2)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 3)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 1)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 5)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 6)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 7)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 8)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 9)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 10)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', 11)->count(), \App\User::where('userable_type', 'App\General\Admin')->whereMonth('created_at', '12')->count()],
                ],[
                    'barPercentage' => 0.5,
                    'label' => 'Companies ('.$companies.')',
                    'backgroundColor' => '#f99037',
                    'data' => [\App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 1)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 2)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 3)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 4)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 5)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 6)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 7)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 8)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 9)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 10)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', 11)->count(), \App\User::where('userable_type', 'App\Company\Company')->whereMonth('created_at', '12')->count()],
                ],[
                    'barPercentage' => 0.5,
                    'label' => 'Marketers ('.$marketers.')',
                    'backgroundColor' => '#098f56',

                    'data' => [\App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', '01')->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', '02')->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 3)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 4)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 5)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 6)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 7)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 8)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', '09')->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 10)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', 11)->count(), \App\User::where('userable_type', 'App\Affilate\Affilate')->whereMonth('created_at', '12')->count()],
                ],[
                    'barPercentage' => 0.5,
                    'label' => 'Customers ('.$customers.')',
                    'backgroundColor' => '#f2cb22',
                    'data' => [\App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 1)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 2)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 3)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 4)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 5)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 6)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 7)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 8)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 9)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 10)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', 11)->count(), \App\User::where('userable_type', 'App\Customer\Customer')->whereMonth('created_at', '12')->count()],
                ]))
                ->options([
                    'xaxis' => [
                        'categories' => [ 'Jan', 'Feb','Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                    ],
                    'btnRefresh' => true, // default is false
                ])
                ->width('2/3'),
            (new TotalUsers),
            new allAdmins,
            new allCompanies,
            new allMarheters,
            new allCustomers,
        ];
    }

    /**
     * Get the extra dashboards that should be displayed on the Nova dashboard.
     *
     * @return array
     */
    protected function dashboards()
    {
        return [];
    }

    /**
     * Get the tools that should be listed in the Nova sidebar.
     *
     * @return array
     */
    public function tools()
    {
        return [];
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
