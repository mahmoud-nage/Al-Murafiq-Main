<?php

namespace App\Nova;

use Illuminate\Http\Request;
use Laravel\Nova\Fields\BelongsToMany;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Trix;
use Laravel\Nova\Http\Requests\NovaRequest;

class Subscription extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\General\Subscription::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'name_en';
    public static $group = 'Companies';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),

            Text::make('Name Arabic', 'name_ar')
                ->rules('required', 'max:190')
                ->sortable(),
            Text::make('Name English', 'name_en')
                ->rules('required', 'max:190')
                ->sortable(),


            Trix::make('Description Arabic', 'desc_ar')->rules('required'),
            Trix::make('Description English', 'desc_en')->rules('required'),

            Number::make('price')
                ->default(1)->step(0.01)->min(1)
                ->sortable(),
            Number::make('Period Of Subscription Per Day', 'days')
                ->default(1)->step(1)->min(1)
                ->sortable(),
            Number::make('# Of Slider Show In Ad', 'slider_num')
                ->default(1)->step(1)->min(1)
                ->sortable(),
            Number::make('# Of Banner Show In Ad', 'banner_num')
                ->default(1)->step(1)->min(1)
                ->sortable(),
            Number::make('Total Company Subscriped', 'total_company')
                ->default(1)->step(1)->min(1)
                ->sortable()->exceptOnForms(),
            Boolean::make('Special', 'top')->trueValue(1)->falseValue(0)->sortable()->default(0),
            Boolean::make('active')->trueValue(1)->falseValue(0)->sortable()->default(1),
            BelongsToMany::make('companies'),
            BelongsToMany::make('ads'),

        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
