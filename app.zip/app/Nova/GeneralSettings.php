<?php

namespace App\Nova;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Number;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Trix;
use Laravel\Nova\Http\Requests\NovaRequest;

class GeneralSettings extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\General\GeneralSettings::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'id';
    public static $group = 'Setting';


    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),
            Text::make('Site Name Arabic','site_ar')
                ->rules('required', 'max:190')
                ->sortable(),
            Text::make('Site Name English','site_en')
                ->rules('required', 'max:190')
                ->sortable(),

            Text::make('Address Arabic','address_ar')
                ->rules('required', 'max:190')
                ->sortable(),
            Text::make('Address English','address_en')
                ->rules('required', 'max:190')
                ->sortable(),

            Image::make( 'favicon')
                ->disk('Root')
                ->store(function (Request $request, $model) {
                    $filename = Str::random(50) . '.' . $request->favicon->getClientOriginalExtension();
                    $request->favicon->move(public_path('/uploads/generalSettings/'), $filename);
                    return [
                        'favicon' => '/uploads/generalSettings/' . $filename,
                    ];
                })
                ->prunable()
                ->creationRules('required', 'image', 'mimes:png,jpeg,jpg,gif')
                ->updateRules('image', 'mimes:png,jpeg,jpg,gif'),

            Image::make( 'logo')
                ->disk('Root')
                ->store(function (Request $request, $model) {
                    $filename = Str::random(50) . '.' . $request->logo->getClientOriginalExtension();
                    $request->logo->move(public_path('/uploads/generalSettings/'), $filename);
                    return [
                        'logo' => '/uploads/generalSettings/' . $filename,
                    ];
                })
                ->prunable()
                ->creationRules('required', 'image', 'mimes:png,jpeg,jpg,gif')
                ->updateRules('image', 'mimes:png,jpeg,jpg,gif'),

            Number::make('lat')->rules('max:20')->default(0),
            Number::make('lon')->rules('max:20')->default(0),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
