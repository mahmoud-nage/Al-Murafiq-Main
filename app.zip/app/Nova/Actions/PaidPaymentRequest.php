<?php

namespace App\Nova\Actions;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Http\Request;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Fields\ActionFields;
use Laravel\Nova\Fields\Image;

class PaidPaymentRequest extends Action
{
    use InteractsWithQueue, Queueable;

    /**
     * Perform the action on the given models.
     *
     * @param  \Laravel\Nova\Fields\ActionFields  $fields
     * @param  \Illuminate\Support\Collection  $models
     * @return mixed
     */
    public function handle(ActionFields $fields, Collection $models)
    {
        foreach ($models as $model){
            $model->update(['status'=>1]);
        }

    }

    /**
     * Get the fields available on the action.
     *
     * @return array
     */
    public function fields()
    {
        return [
            Image::make('Payment Image', 'file')
                ->disk('Root')
                ->store(function (Request $request, $model) {
                    $filename = Str::random(50) . '.' . $request->file->getClientOriginalExtension();
                    $request->file->move(public_path('/images/payments/'), $filename);
                    return [
                        'file' => '/images/payments/' . $filename,
                    ];
                })
                ->prunable()
                ->creationRules('required', 'image', 'mimes:png,jpeg,webp,hpg,gif')
                ->updateRules('image', 'mimes:png,jpeg,webp,hpg,gif'),
        ];
    }
}
