<?php

namespace App\Nova\Actions;

use App\General\Payment;
use App\General\Subscription;
use Illuminate\Bus\Queueable;
use Laravel\Nova\Fields\Date;
use App\General\PaymentMethod;
use Illuminate\Support\Carbon;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Fields\Boolean;
use Illuminate\Support\Collection;
use App\General\CampanySubsriptions;
use Laravel\Nova\Fields\ActionFields;
use Illuminate\Queue\InteractsWithQueue;

class AttachSubscription extends Action
{
    use InteractsWithQueue, Queueable;

    /**
     * Perform the action on the given models.
     *
     * @param  \Laravel\Nova\Fields\ActionFields  $fields
     * @param  \Illuminate\Support\Collection  $models
     * @return mixed
     */
    public function handle(ActionFields $fields, Collection $models)
    {
        foreach($models as $model){
            $subs = Subscription::find($models->subscription_id);
            $user = $model->user;
            
            $subrel = CampanySubsriptions::create([
                'subscription_id' => $models->subscription_id,
                'company_id' => $model->id,
                'from' => $fields->from,
                'to' => date('Y-m-d', strtotime($fields->from. ' + '.$subs->days.' day')),
                'price' => $subs->price,
                'slider_num' => $subs->slider_num,
                'banner_num' => $subs->banner_num,
            ]);

            $payment = Payment::create([
                'user_id' => $user->id,
                'payment_method_id' => $fields->paymentMethod,
                'company_subsription_id' => $subrel->id,
                'amount' => $subs->price,
                'payment_status' => $fields->payment_status,
            ]);

            $subrel->update([
                'payment_id' => $payment->id
            ]);
        }
    }

    /**
     * Get the fields available on the action.
     *
     * @return array
     */
    public function fields()
    {
        return [
            // Select::make('Subscription', 'subscription_id')->options(function () {
            //     $Subscriptions = \App\General\Subscription::all();
            //     $data=[];
            //     foreach ($Subscriptions as $Subscription) {
            //         $data[$Subscription->id] = $Subscription['name_' . app()->getLocale()]. '  -  '.$Subscription->price;
            //     }
            //     return $data;

            // })->searchable()->rules('required'),
            // Date::make('from')->rules('required','after_or_equal:today'),
            // // Date::make('to')->rules('required'),
            // Select::make('paymentMethod', 'paymentMethod')->options(function () {
            //     $PaymentMethods = \App\General\PaymentMethod::all();
            //     $data=[];
            //     foreach ($PaymentMethods as $PaymentMethod) {
            //         $data[$PaymentMethod->id] = $PaymentMethod['name_' . app()->getLocale()];
            //     }
            //     return $data;
            // })->searchable()->rules('required'),
            // Boolean::make('Payment Status', 'payment_status')->trueValue(1)->falseValue(0)->sortable()->default(0),

        ];
    }
}
