<?php

namespace App\Nova;

use Illuminate\Support\Str;
use Laravel\Nova\Fields\ID;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\Date;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Place;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\HasMany;
use Laravel\Nova\Fields\MorphTo;
use Laravel\Nova\Fields\Gravatar;
use Laravel\Nova\Fields\Password;
use Laravel\Nova\Fields\BelongsToMany;
use Laravel\Nova\Http\Requests\NovaRequest;

class User extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\User::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'name';
    public static $group = 'Users';
    public static $displayInNavigation = false;


    protected static function fillFields(NovaRequest $request, $model, $fields)
    {
        $fillFields = parent::fillFields($request, $model, $fields);

        // first element should be model object
        $modelObject = $fillFields[0];

        // remove all attributes do not have relevant columns in model table
        unset($modelObject->country_id);

        return $fillFields;
    }


    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'name', 'email',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [
            ID::make()->sortable(),

            MorphTo::make('userable')->types([
                Admin::class,
                Affilate::class,
                Company::class,
                Customer::class,
            ])->readonly(),

            Gravatar::make()->maxWidth(50),

            Text::make('Name')
                ->sortable()
                ->rules('required', 'max:191'),

            Text::make('Email')
                ->sortable()
                ->rules('required', 'email', 'max:191')
                ->creationRules('unique:users,email')
                ->updateRules('unique:users,email,{{resourceId}}'),

            Password::make('Password')
                ->onlyOnForms()
                ->creationRules('required', 'string', 'min:8')
                ->updateRules('nullable', 'string', 'min:8')->onlyOnForms(),

            Text::make('provider')
                ->sortable()
                ->rules('max:191')->onlyOnDetail(),
            Text::make('Provider Id','provider_id')
                ->sortable()
                ->rules('max:191')->onlyOnDetail(),

            Image::make('Profile Photo', 'avatar')
                ->disk('Root')
                ->store(function (Request $request, $model) {
                    $filename = Str::random(50) . '.' . $request->avatar->getClientOriginalExtension();
                    $request->avatar->move(public_path('/uploads/users/'), $filename);
                    return [
                        'avatar' => '/uploads/users/' . $filename,
                    ];
                })
                ->prunable()
                ->creationRules('image', 'mimes:png,jpeg,jpg,gif')
                ->updateRules('image', 'mimes:png,jpeg,jpg,gif')->hideFromIndex(),

            Date::make('Birth Date','birth_date')
                ->sortable()->hideFromIndex(),

            Select::make( 'gender')->options([
                'Male' => 'Male',
                'Female' => 'Female'
            ])->hideFromIndex(),

            Select::make( 'Default Language','default_lang')->options([
                'ar' => 'AR',
                'en' => 'EN'
            ])->searchable()->rules('required')->hideFromIndex(),

            Text::make('phone')
                ->sortable()
                ->rules('required', 'max:191'),


            
                        Select::make('Country', 'country_id')->options(function () {
                            $countries = \App\General\Country::where('active', 1)->get();
                            $data =[];
                            foreach ($countries as $country) {
                                $data[$country->id] = $country['name_' . app()->getLocale()];
                            }
                            return $data;
            
                        })->searchable()->rules('required'),
            
                        Select::make('City', 'city_id')->options(function () {
                            $countries = \App\General\City::where('active', 1)->get();
                            $data =[];
                            foreach ($countries as $country) {
                                $data[$country->id] = $country['name_' . app()->getLocale()];
                            }
                            return $data;
            
                        })->searchable()->rules('required'),
            
                        Select::make('Area', 'area_id')->options(function () {
                            $countries = \App\General\Area::where('active', 1)->get();
                            $data =[];
                            foreach ($countries as $country) {
                                $data[$country->id] = $country['name_' . app()->getLocale()];
                            }
                            return $data;
            
                        })->searchable()->hideFromIndex()->rules('required'),
            
                        Select::make('Zone', 'zone_id')->options(function () {
                            $countries = \App\General\Zone::all();
                            $data =[];
                            foreach ($countries as $country) {
                                $data[$country->id] = $country['name_' . app()->getLocale()];
                            }
                            return $data;
            
                        })->searchable()->hideFromIndex()->rules('required'),
            
            

            Text::make('reset_code')
                ->sortable()->exceptOnForms()->onlyOnDetail(),

            Text::make('national_id')
                ->sortable()->nullable(),

            Text::make('api_token')
                ->sortable()->exceptOnForms()->onlyOnDetail(),
            Text::make('fcm_token')
                ->sortable()->exceptOnForms()->onlyOnDetail(),

            Boolean::make('active')->trueValue(1)->falseValue(0)->sortable()->default(1),

            HasMany::make('addresses'),
            HasMany::make('payments'),
            HasMany::make('contacts'),
//            HasMany::make('tickets'),
            HasMany::make('reviews'),
            HasMany::make('wishlists'),

        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
