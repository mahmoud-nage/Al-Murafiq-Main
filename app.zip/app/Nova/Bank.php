<?php

namespace App\Nova;

use App\General\Banks;
use App\Nova\Resource;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Text;

class Bank extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\General\Banks::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'id';
    public static $group = 'Setting';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id', 'bank_name_ar',
        'bank_name_en', 'branch_name_ar',
        'branch_name_en', 'owner_name_ar',
        'owner_name_en', 'account_num',
        'swift_num',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),

            Text::make('Bank Name Arabic', 'bank_name_ar')
                ->rules('required', 'max:190')
                ->sortable(),

            Text::make('Bank Name English', 'bank_name_en')
                ->rules('required', 'max:190')
                ->sortable(),

            Text::make('Branch Name Arabic', 'branch_name_ar')
                ->rules('required', 'max:190')
                ->sortable()->hideFromIndex(),

            Text::make('Branch Name English', 'branch_name_en')
                ->rules('required', 'max:190')
                ->sortable()->hideFromIndex(),

            Text::make('Owner Name Arabic', 'owner_name_ar')
                ->rules('required', 'max:190')
                ->sortable()->hideFromIndex(),

            Text::make('Owner Name English', 'owner_name_en')
                ->rules('required', 'max:190')
                ->sortable()->hideFromIndex(),

            Text::make('Account Number', 'account_num')
                ->rules('required', 'max:190')
                ->sortable(),

            Text::make('Swift Number', 'swift_num')
                ->rules('required', 'max:190')
                ->sortable(),

            Image::make('Bank Logo', 'logo')
                ->disk('Root')
                ->store(function (Request $request, $model) {
                    $filename = Str::random(50) . '.' . $request->logo->getClientOriginalExtension();
                    $request->logo->move(public_path('/uploads/banks/'), $filename);
                    return [
                        'logo' => '/uploads/banks/' . $filename,
                    ];
                })
                ->prunable()
                ->creationRules('required', 'image', 'mimes:png,jpeg,jpg,gif')
                ->updateRules('image', 'mimes:png,jpeg,jpg,gif'),

            Boolean::make('active')->trueValue(1)->falseValue(0)->sortable()->default(0),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
