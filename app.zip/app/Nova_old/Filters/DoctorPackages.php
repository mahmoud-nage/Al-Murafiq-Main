<?php

namespace App\Nova\Filters;

use App\Model\Package;
use Illuminate\Http\Request;
use Laravel\Nova\Filters\Filter;

class DoctorPackages extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'select-filter';

    /**
     * Apply the filter to the given query.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  mixed  $value
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function apply(Request $request, $query, $value)
    {
        return $query->where('package_id', $value);
    }

    /**
     * Get the filter's available options.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function options(Request $request)
    {
        $packages = Package::all();
        $values =[];
        foreach ($packages as $package) {
            $values[$package['name_'.app()->getLocale()]] = $package->id;
        }
        return $values;
    }
}
