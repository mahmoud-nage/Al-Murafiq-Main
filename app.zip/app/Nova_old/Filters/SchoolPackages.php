<?php

namespace App\Nova\Filters;

use App\Model\PackageCategory;
use Illuminate\Http\Request;
use Laravel\Nova\Filters\Filter;

class SchoolPackages extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'select-filter';

    /**
     * Apply the filter to the given query.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  mixed  $value
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function apply(Request $request, $query, $value)
    {
        return $query->PackageCategories->where('package_category_id',$value);
    }

    /**
     * Get the filter's available options.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function options(Request $request)
    {
        $packages = PackageCategory::all();
        $values =[];
        foreach ($packages as $package) {
            $values[$package['name_'.app()->getLocale()]] = $package->id;
        }
        return $values;
    }
}
