<?php

namespace App\Nova\Filters;

use App\Model\Disease;
use App\Model\School;
use Illuminate\Http\Request;
use Laravel\Nova\Filters\Filter;

class schoolFilter extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'select-filter';

    /**
     * Apply the filter to the given query.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  mixed  $value
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function apply(Request $request, $query, $value)
    {
        return $query->where('school_id', $value);

    }

    /**
     * Get the filter's available options.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function options(Request $request)
    {
        $schools = School::all();
        return $schools->pluck('id', 'school_name')->all();    }
}
