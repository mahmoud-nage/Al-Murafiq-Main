<?php

namespace App\Nova;

use Illuminate\Support\Str;
use Laravel\Nova\Fields\ID;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Image;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\BelongsTo;

class Ad extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var string
     */
    public static $model = \App\General\Ad::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'name_en';

    public static $group = 'Companies';


    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = [
        'id',
    ];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [
            ID::make(__('ID'), 'id')->sortable(),
//            BelongsTo::make('companySubsriptions', 'companySubsriptions', 'App\Nova\companySubsriptions')->rules('required'),

            BelongsTo::make('Company', 'company', 'App\Nova\Company')->rules('required'),
            BelongsTo::make('Subscription', 'subscription', 'App\Nova\Subscription')->rules('required'),

            Select::make('Ad Location', 'ad_location')->options([
                1 => 'Home',
                2 => 'Category',
            ])->searchable()->rules('required'),

            Select::make('Type', 'type')->options([
                1 => 'Banner',
                2 => 'Slider',
            ])->searchable()->rules('required'),

            Boolean::make('Special', 'top')->trueValue(1)->falseValue(0)->sortable()->default(0),

            // Boolean::make('active')->trueValue(1)->falseValue(0)->sortable()->default(0),

            Image::make('Image', 'image')
                ->disk('Root')
                ->store(function (Request $request, $model) {
                    $filename = Str::random(50) . '.' . $request->image->getClientOriginalExtension();
                    $request->image->move(public_path('/uploads/ads/'), $filename);
                    return [
                        'image' => '/uploads/ads/' . $filename,
                    ];
                })
                ->prunable()
                ->rules('image', 'mimes:png,jpeg,jpg,gif'),

        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
