<template functional>
  <transition name="fade" mode="out-in"> <slot /> </transition>
</template>
